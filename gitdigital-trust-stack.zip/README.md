# GitDigital Trust Stack

Add compliant, private, and reputation-based users to your Solana app.

## Install
npm install gitdigital-trust

## Usage
```js
import { verifyUser, createMask, assignBadge } from "gitdigital-trust";

const user = await verifyUser("wallet_address");
const mask = await createMask(user);
await assignBadge(mask, "verified_user");
```
