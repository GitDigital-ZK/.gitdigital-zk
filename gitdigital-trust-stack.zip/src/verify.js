export async function verifyUser(wallet) {
  return { wallet, verified: true };
}