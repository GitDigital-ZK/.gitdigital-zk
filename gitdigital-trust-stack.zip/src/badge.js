export async function assignBadge(mask, badge) {
  return { ...mask, badge };
}