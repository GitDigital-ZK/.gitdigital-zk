export async function createMask(user) {
  return { maskId: "mask_" + user.wallet };
}