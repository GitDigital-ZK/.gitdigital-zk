import { verifyUser, createMask, assignBadge } from "../src/index.js";

async function run() {
  const user = await verifyUser("demo_wallet");
  const mask = await createMask(user);
  const result = await assignBadge(mask, "verified_user");
  console.log(result);
}

run();