# GitDigital Trust Stack (Full)

This bundle connects:
- zk-KYC SDK
- zk-Identity Masks
- ZK Badge Authority

## Flow
verifyUser → createMask → assignBadge

Integrate your real repos into these modules.
