// Replace with zk-solana-kyc-compliance-sdk
export async function verifyUser(wallet) {
  return { wallet, verified: true };
}