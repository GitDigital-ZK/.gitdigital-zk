// Replace with zk-Identity-masks repo logic
export async function createMask(user) {
  return { maskId: "mask_" + user.wallet };
}