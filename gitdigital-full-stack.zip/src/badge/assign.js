// Replace with ZK Badge Authority logic
export async function assignBadge(mask, badge) {
  return { ...mask, badge };
}