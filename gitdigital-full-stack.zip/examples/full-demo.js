import { verifyUser, createMask, assignBadge } from "../src/index.js";

async function run() {
  const user = await verifyUser("wallet_123");
  const mask = await createMask(user);
  const result = await assignBadge(mask, "verified_human");
  console.log(result);
}

run();