# Plug Your Real Repos Here

- zk-solana-kyc-compliance-sdk → src/kyc/
- zk-Identity-masks → src/identity/
- ZK-5D-Cryptographic-Badge-Authority → src/badge/

Replace mock logic with real implementations.
